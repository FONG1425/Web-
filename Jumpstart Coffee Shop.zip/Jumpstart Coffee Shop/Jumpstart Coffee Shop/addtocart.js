function addtocart(){
    document.location.href="addto_cart.html";
}